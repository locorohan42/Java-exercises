package century.edu.pa1;

public class SimpleTest {
	public static void main(String[] args) {
		PayCalculator John = new PayCalculator("John", 39);
		System.out.println(John);
		PayCalculator Jack = new PayCalculator("Jack", 52);
		System.out.println(Jack);
		Jack.increaseHourlyWage(20);
		
		System.out.println(Jack);
		
		
		
	}

}
