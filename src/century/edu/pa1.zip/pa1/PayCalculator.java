package century.edu.pa1;

import java.lang.reflect.Array;

public class PayCalculator implements Constants{
	
	//Instance Variables
	private String name;
	private int reportId;
	private static int idIncrement;
	private double hourlyWage;
	
	
	//Constructor
	public PayCalculator(String name, double hourlyWage) {
		this.name = name;
		this.reportId = 1000 + idIncrement;
		this.hourlyWage = hourlyWage;
		idIncrement+=10;
	}
	
	
	//Method will increase the wage by a given percentage
	//Will take in a rate that will change the wage
	//the rate must be positive
	//Will return the new hourly wage
	//Throws an exception if the rate is <= 0   ***********************
	public void increaseHourlyWage(double rate) {
		double newWage;
		newWage = getHourlyWage() + (getHourlyWage() * (rate/100));
		setHourlyWage(newWage);
	}
	
	//Method caluclates the amount of overtime worked
	//Will take in the amount of hours worked 
	//Hours worked must be positive
	//Will return the amount of overtime worked
	//Throws exception if hoursworked is less than 0
	public double overTimeHoursWorked(double hoursWorked) {
		double overTime;
		if(hoursWorked > FULL_TIME) {
		overTime = hoursWorked - FULL_TIME;
		return overTime;
		}
		return 0;
	}
	
	//Method calculates the amount of overtime pay
	//will take in amount of overtime hours
	//Overtime hours must be postivie
	//Will return the pay for overtime
	//Throws exception if overTimeHours is less than 0
	public double overTimePay(double overTimeHours) {
		double overTimePay = overTimeHours * getHourlyWage() * OVERTIME_RATE;
		return overTimePay;
	}
	
	//Method calculates the amount of pay for a period
	//Will take in the amount of hours worked
	//Hours must be positive
	//Will return the pay for the period
	//Throws exception if hours is less than 0
	public double grossPay(double hoursWorked) {
		double pay = (hoursWorked-overTimeHoursWorked(hoursWorked)) * getHourlyWage();
		return pay;
	}
	
	
	//Method calcualtes the amount of feder deductions
	//Will take in the gross pay
	//Gross pay must be positive
	//Will returnt the amount of federal deductions 
	//Throws exception if grossPay is less than 0
	public double federalDeductions(double grossPay) {
		double federalDeductions = grossPay * FEDERAL_TAX_RATE;
		return federalDeductions;
	}
	
	
	//Method calcualtes the amount of state deductions
	//Will take in the gross pay
	//Gross pay must be positive
	//Will returnt the amount of state deductions 
	//Throws exception if grossPay is less than 0
	public double stateDeductions(double grossPay) {
		double stateDeductions = grossPay * STATE_TAX_RATE;
		return stateDeductions;
	}
	
	//Method calculates the total deductions
	//Will take in federal and state deductions
	//Deductions must be postivie
	//Will return the total amount of deductions
	//Throws exception if one of the parameters is less than 0
	public double totalDeductions(double federalDeductions, double stateDeductions) {
		double totalDeductions = federalDeductions + stateDeductions;
		return totalDeductions;
	}
	
	//Method calculates the net pay. Takes into account deductions that rely on the gross pay
	//Will take in hours worked
	//Hours must be positive
	//Will return the net pay
	//Throws exception if hours worked is less than 0
	public double netPay(double hoursWorked) {
		double netPay = grossPay(hoursWorked) - totalDeductions(grossPay(hoursWorked), grossPay(hoursWorked));
		return netPay;
	}
	
	//Method calculates the gross for the year based on the amount of hours worked each pay period
	//Will take in an array of hours worked per pay period
	//The integer values of the array must be positive
	//Will return the gross year income
	//Throws an exception if one of the hours worked is less than 0
	public double grossYearIncome(int[] hoursPerPayPeriod) {
		double grossYearIncome = 0;
		for(int i = 0; i < hoursPerPayPeriod.length; i++) {
			double pay = grossPay(i);
			pay+=grossYearIncome;
		}
			
		return grossYearIncome;
		
	}
	
	//Method calculates the net pay for the year based on the amount of hours worked each pay period
	//Will take in an array of hours worked per pay period
	//The integer values of the array must be positive
	//Will return the net year income
	//Throws an exception if one of the hours worked is less than 0
	public double netYearIncome(int[] hoursPerPayPeriod) {
		double grossYearIncome = grossYearIncome(hoursPerPayPeriod);
		double netYearIncome = grossYearIncome - totalDeductions(grossYearIncome, grossYearIncome);
		return netYearIncome;
	}

	
	
	
	
	//Getters and Setters
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getReportId() {
		return reportId;
	}

	public void setReportId(int reportID) {
		this.reportId = reportID;
	}

	public double getHourlyWage() {
		return hourlyWage;
	}

	public void setHourlyWage(double hourlyWage) {
		this.hourlyWage = hourlyWage;
	}
	
	//ToString method
	public String toString() {
        
       return "Name: " + this.name + " ID: " + this.reportId + " Hourly Wage: " + this.hourlyWage;
    		   
    }




	

	
	


	

	

	
	

	
	

}
